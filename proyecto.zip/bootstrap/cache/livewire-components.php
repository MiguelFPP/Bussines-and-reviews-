<?php return array (
  'bussines.home' => 'App\\Http\\Livewire\\Bussines\\Home',
  'panel.create' => 'App\\Http\\Livewire\\Panel\\Create',
  'panel.edit' => 'App\\Http\\Livewire\\Panel\\Edit',
  'panel.index' => 'App\\Http\\Livewire\\Panel\\Index',
  'review.create' => 'App\\Http\\Livewire\\Review\\Create',
  'review.index' => 'App\\Http\\Livewire\\Review\\Index',
);