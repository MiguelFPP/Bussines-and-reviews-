<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-6">
            <h1 class="text-center float-start">Listado de Negocios</h1>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('bussines.home')); ?>" class="btn btn-primary float-end">
                Panel de negocios
            </a>
        </div>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bussines.home')->html();
} elseif ($_instance->childHasBeenRendered('9Fd6Bnj')) {
    $componentId = $_instance->getRenderedChildComponentId('9Fd6Bnj');
    $componentTag = $_instance->getRenderedChildComponentTagName('9Fd6Bnj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9Fd6Bnj');
} else {
    $response = \Livewire\Livewire::mount('bussines.home');
    $html = $response->html();
    $_instance->logRenderedChild('9Fd6Bnj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/main/home.blade.php ENDPATH**/ ?>