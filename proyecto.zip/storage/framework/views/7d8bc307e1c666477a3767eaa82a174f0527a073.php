<div class="container">
    <div class="shadow border rounded-3 mx-5 p-3">
        <?php if($edited): ?>
        <div class="alert alert-success">
            Negocio editado con éxito
        </div>
        <?php endif; ?>
        <form wire:submit.prevent='update'>
            <div class="form-group mb-2">
                <label for="name">Nombre Negocio</label>
                <input type="text" name="name" id="" class="form-control" placeholder="Ingrese el nombre de su negocio"
                    wire:model="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger text-sm">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mb-2">
                <label for="phone">Numero telefono</label>
                <input type="tel" name="phone" id="" placeholder="Ingrese el numero de telefono de su negocio"
                    class="form-control" wire:model="phone">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger text-sm">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mb-2">
                <label for="name">Descripción</label>
                <textarea name="description" id="" cols="30" rows="10" class="form-control"
                    placeholder="Ingrese una descripcion para su negocio" wire:model="description"></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger text-sm">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <label for="">Imagen Actual</label>
            <div class="form-group d-flex justify-content-center">
                
                <?php if(strpos($image, 'http') !== false): ?>
                <img src="<?php echo e($image); ?>" class="img-fluid rounded mb-2 w-25" alt="<?php echo e($name); ?>">
                <?php else: ?>
                <img src="<?php echo e(Storage::url($image)); ?>" alt="" class="img-thumbnail mb-2 w-25 rounded">
                <?php endif; ?>
            </div>

            <div class="form-group mb-2">
                <label for="image">Imagen de su negocio</label>
                <input type="file" name="image" id="" class="form-control" wire:model='image_new' accept="image/*">
                <?php $__errorArgs = ['image_new'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger text-sm">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <button type="submit" class="btn btn-success btn-md w-100">Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\crud-negocios\resources\views/livewire/panel/edit.blade.php ENDPATH**/ ?>