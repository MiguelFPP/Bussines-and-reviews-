<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-6">
            <h3 class="text-center">Reseña para: <?php echo e($busine->name); ?></h3>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('main.bussines.show', $busine)); ?>" class="btn btn-primary float-end">
                Volver
            </a>
        </div>
    </div>

    
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('review.create', ['busine' => $busine])->html();
} elseif ($_instance->childHasBeenRendered('nYKQjZA')) {
    $componentId = $_instance->getRenderedChildComponentId('nYKQjZA');
    $componentTag = $_instance->getRenderedChildComponentTagName('nYKQjZA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nYKQjZA');
} else {
    $response = \Livewire\Livewire::mount('review.create', ['busine' => $busine]);
    $html = $response->html();
    $_instance->logRenderedChild('nYKQjZA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/main/review.blade.php ENDPATH**/ ?>