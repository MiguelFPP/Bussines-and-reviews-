<div class="container">
    <div class="mx-5">
        <?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border rounded-3 py-2 px-3 mb-2">
            <?php echo e($bussine->name); ?>

            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('bussines.edit', $bussine)); ?>" class="btn btn-primary">Editar</a>
                <button class="btn btn-danger float-right"
                    wire:click="$emit('deleteB', <?php echo e($bussine->id); ?>)">Eliminar</button>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-2 d-flex justify-content-center">
        <?php echo $bussines->links(); ?>

    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Livewire.on('deleteB', (id) => {
            Swal.fire({
                title: 'Estas Seguro?',
                text: "No podra revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Eliminar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    /* aliminar vacante */
                    Livewire.emit('delete', id)
                    Swal.fire(
                        'Eliminada!',
                        'El negocio ha sido eliminado.',
                        'success'
                    )
                }
            })
        });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\crud-negocios\resources\views/livewire/panel/index.blade.php ENDPATH**/ ?>