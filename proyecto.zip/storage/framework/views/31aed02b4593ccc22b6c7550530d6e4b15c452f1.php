<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-6">
            <h1 class="text-center float-start">Editar: <?php echo e($busine->name); ?></h1>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('bussines.home')); ?>" class="btn btn-primary float-end">
                Volver
            </a>
        </div>
    </div>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.edit', ['busine' => $busine])->html();
} elseif ($_instance->childHasBeenRendered('HOI3dLs')) {
    $componentId = $_instance->getRenderedChildComponentId('HOI3dLs');
    $componentTag = $_instance->getRenderedChildComponentTagName('HOI3dLs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HOI3dLs');
} else {
    $response = \Livewire\Livewire::mount('panel.edit', ['busine' => $busine]);
    $html = $response->html();
    $_instance->logRenderedChild('HOI3dLs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/panel/edit.blade.php ENDPATH**/ ?>