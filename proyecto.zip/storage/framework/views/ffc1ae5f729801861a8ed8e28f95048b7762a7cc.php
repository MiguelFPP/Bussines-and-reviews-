<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-6">
            <h1 class="text-center float-star">Crud de negocios</h1>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary float-end">
                Panel de negocios
            </a>
            <a href="<?php echo e(route('bussines.create')); ?>" class="btn btn-primary float-end mx-2">
                Agregar negocio
            </a>
        </div>
    </div>

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.index')->html();
} elseif ($_instance->childHasBeenRendered('QwGF5cU')) {
    $componentId = $_instance->getRenderedChildComponentId('QwGF5cU');
    $componentTag = $_instance->getRenderedChildComponentTagName('QwGF5cU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QwGF5cU');
} else {
    $response = \Livewire\Livewire::mount('panel.index');
    $html = $response->html();
    $_instance->logRenderedChild('QwGF5cU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/panel/index.blade.php ENDPATH**/ ?>