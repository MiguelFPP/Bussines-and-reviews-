<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-6">
            <h1 class="text-center float-start">Crear de negocios</h1>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('bussines.home')); ?>" class="btn btn-primary float-end">
                Volver
            </a>
        </div>
    </div>

    
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('panel.create')->html();
} elseif ($_instance->childHasBeenRendered('pKmdVA9')) {
    $componentId = $_instance->getRenderedChildComponentId('pKmdVA9');
    $componentTag = $_instance->getRenderedChildComponentTagName('pKmdVA9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pKmdVA9');
} else {
    $response = \Livewire\Livewire::mount('panel.create');
    $html = $response->html();
    $_instance->logRenderedChild('pKmdVA9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/panel/create.blade.php ENDPATH**/ ?>