<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('4qRa2kR')) {
    $componentId = $_instance->getRenderedChildComponentId('4qRa2kR');
    $componentTag = $_instance->getRenderedChildComponentTagName('4qRa2kR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4qRa2kR');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('4qRa2kR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\laragon\www\crud-negocios\vendor\livewire\livewire\src\Testing/../views/mount-component.blade.php ENDPATH**/ ?>