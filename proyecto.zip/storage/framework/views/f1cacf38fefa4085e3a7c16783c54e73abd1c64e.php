<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col-12 text-center">
            <h1 class="text-center"><?php echo e($busine->name); ?></h1>
        </div>

        <div class="col-12">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary float-end">
                Volver
            </a>
        </div>
        <div class="col-12 d-flex justify-content-center">
            <?php if(strpos($busine->image_url, 'http') !== false): ?>
            <img src="<?php echo e($busine->image_url); ?>" class="img-fluid rounded w-50" alt="<?php echo e($busine->name); ?>">
            <?php else: ?>
            <img src="<?php echo e(Storage::url($busine->image_url)); ?>" class="img-fluid rounded w-50" alt="...">
            <?php endif; ?>
        </div>

        <div class="col-6">
            <h3 class="fw-bold"><?php echo e($busine->phone); ?></h3>
        </div>
        <div class="col-12">
            <p><?php echo e($busine->description); ?></p>
        </div>
        
        
    </div>

    <div class="container mt-2">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('review.index', ['busine' => $busine])->html();
} elseif ($_instance->childHasBeenRendered('yBD7Ku4')) {
    $componentId = $_instance->getRenderedChildComponentId('yBD7Ku4');
    $componentTag = $_instance->getRenderedChildComponentTagName('yBD7Ku4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yBD7Ku4');
} else {
    $response = \Livewire\Livewire::mount('review.index', ['busine' => $busine]);
    $html = $response->html();
    $_instance->logRenderedChild('yBD7Ku4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crud-negocios\resources\views/main/show.blade.php ENDPATH**/ ?>