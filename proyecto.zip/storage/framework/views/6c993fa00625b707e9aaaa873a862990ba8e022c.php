<div class="mx-5 p-3 shadow border rounded-3">
    <?php if($created): ?>
    <div class="alert alert-success">
        Negocio registrado con éxito
    </div>

    <?php endif; ?>
    <form wire:submit.prevent='store'>
        <div class="form-group mb-2">
            <label for="name">Nombre Negocio</label>
            <input type="text" name="name" id="" class="form-control" placeholder="Ingrese el nombre de su negocio"
                wire:model="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger text-sm">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-2">
            <label for="phone">Numero telefono</label>
            <input type="tel" name="phone" id="" placeholder="Ingrese el numero de telefono de su negocio"
                class="form-control" wire:model="phone">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger text-sm">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-2">
            <label for="name">Descripción</label>
            <textarea name="description" id="" cols="30" rows="10" class="form-control"
                placeholder="Ingrese una descripcion para su negocio" wire:model="description"></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger text-sm">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-2">
            <label for="image">Imagen de su negocio</label>
            <input type="file" name="image" id="" class="form-control" wire:model='image' accept="image/*">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger text-sm">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mt-3 ">
            <button type="submit" class="btn btn-success btn-md w-100">Guardar</button>
        </div>
    </form>
</div>
<?php /**PATH C:\laragon\www\crud-negocios\resources\views/livewire/panel/create.blade.php ENDPATH**/ ?>