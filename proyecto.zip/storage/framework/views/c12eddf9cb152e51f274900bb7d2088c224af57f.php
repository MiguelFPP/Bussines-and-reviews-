<div class="container">
    <div class="mx-5">
        <?php $__currentLoopData = $bussines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="shadow p-3 mb-3 bg-body rounded d-flex justify-content-between">
            <div class="row">
                <div class="col-3" style="display: block">
                    <div class="d-flex justify-content-start">
                        
                        <?php if(strpos($bussine->image_url, 'http') !== false): ?>
                        <img src="<?php echo e($bussine->image_url); ?>" class="img-fluid rounded" alt="<?php echo e($bussine->name); ?>">
                        <?php else: ?>
                        <img src="<?php echo e(Storage::url($bussine->image_url)); ?>" class="img-fluid rounded"
                            alt="<?php echo e($bussine->name); ?>">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-9">
                    <div class="d-flex align-items-start flex-row justify-content-end">
                        <?php for($i = 0; $i < $bussine->rating; $i++): ?>
                            <img src="<?php echo e(asset('images/star-gold.png')); ?>" alt="" style="width: 2rem">
                            <?php endfor; ?>

                            <?php for($i = 0; $i < 5 - $bussine->rating; $i++): ?>
                                <img src="<?php echo e(asset('images/star.png')); ?>" alt="" style="width: 2rem">
                                <?php endfor; ?>
                    </div>
                    <a href="<?php echo e(route('main.bussines.show', $bussine)); ?>">
                        <h5><?php echo e($bussine->name); ?></h5>
                    </a>
                    <span class="fw-bold"><?php echo e($bussine->phone); ?></span>
                    <p><?php echo e($bussine->description); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-2 d-flex justify-content-center">
        <?php echo $bussines->links(); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\crud-negocios\resources\views/livewire/bussines/home.blade.php ENDPATH**/ ?>