<div class="mx-5">
    <div class="d-flex justify-content-between mb-2">
        <div class="col-6">
            <h3 class="fw-bold">Reseñas</h3>
        </div>
        <div class="col-6">
            <a href="<?php echo e(route('main.bussines.review', $busine)); ?>" class="btn btn-primary float-end">
                Agregar
            </a>
        </div>
    </div>
    <?php if($busine->reviews->count() === 0): ?>
    <div class="alert alert-info">
        No hay reseñas para este negocio
    </div>
    <?php else: ?>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shadow p-3 mb-3 bg-body rounded d-flex justify-content-between">

        <div>
            <a href="">
                <img src="<?php echo e(asset('images/user.png')); ?>" class="" alt="usuario">
            </a>
        </div>
        <div class="align-items-center w-75">
            <h5><?php echo e($review->user); ?></h5>
            <p><?php echo e($review->description); ?></p>
        </div>
        <div class="flex-row-reverse">
            <div class="form-group">
                <?php for($i = 0; $i < $review->rating; $i++): ?>
                    <img src="<?php echo e(asset('images/star-gold.png')); ?>" alt="" style="width: 10%">
                    <?php endfor; ?>

                    <?php for($i = 0; $i < 5 - $review->rating; $i++): ?>
                        <img src="<?php echo e(asset('images/star.png')); ?>" alt="" style="width: 10%">
                        <?php endfor; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="mt-2 d-flex justify-content-center">
        <?php echo $reviews->links(); ?>

    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\crud-negocios\resources\views/livewire/review/index.blade.php ENDPATH**/ ?>